#Further information

FoX evolved from the initial codebase of [xmlf90](http://lcdx00.wm.lc.ehu.es/ag/xml/),
which was written largely by Alberto Garcia <<albertog@icmab.es>> and Jon Wakelin <<jon.wakelin@bristol.ac.uk>>.

FoX is the work of Toby White <<tow@uszla.me.uk>>, and all bug reports/complaints/bouquets of roses should be sent to him.

There is a FoX website at <http://www.uszla.me.uk/FoX/>.

There is also a mailing list for announcements/queries/bug reports. Information on how to subscribe may be found at <http://www.uszla.me.uk/cgi-bin/mailman/listinfo/FoX/>,

This manual is &copy; Toby White 2006-2008.
