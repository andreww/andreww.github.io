FoX package

Quick start:

1. Type "./configure" to generate appropriate compiler-dependent information for the Makefile.

2. Type "make"

(Optionally)

3. Type "make check"

Full documentation is in DoX/index.html
